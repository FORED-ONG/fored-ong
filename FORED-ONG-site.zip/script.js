const frBtn = document.getElementById('fr-btn');
const enBtn = document.getElementById('en-btn');
const elements = document.querySelectorAll('[data-fr]');

function setLanguage(lang) {
  elements.forEach(el => {
    el.textContent = el.getAttribute(`data-${lang}`);
  });
}

frBtn.addEventListener('click', () => setLanguage('fr'));
enBtn.addEventListener('click', () => setLanguage('en'));
